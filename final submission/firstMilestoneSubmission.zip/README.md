Contributor: Vyas Ramankulangara, Chantha Mak, Deependra Bassnet

How to run the notebook (.ipynb) file attached in this folder:

1. The .ipynb file contains the code that our group used to run the our data pre processing and data visualization
2. The attached csv in our zip file contains the data in our dataset and it is required for our .ipynb file
3. Our report for this 1st milestone can be found in the zip file in the name of datasetReport.pdf